import React, { Fragment } from "react";
import Data from "./Data.json";

class Table extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      tabledata: [
        {
          id: 1,
          product_name: "Weetabix",
          product_category: "Cereal",
          unit_price: "150"
        },
        {
          id: 2,
          product_name: "Colgate Toothpaste",
          product_category: "Toiletries",
          unit_price: "119"
        },
        {
          id: 3,
          product_name: "Imperial Leather Soap",
          product_category: "Toiletries",
          unit_price: "235"
        },
        {
          id: 4,
          product_name: "Sunlight Detergent",
          product_category: "Toiletries",
          unit_price: "401"
        }
      ]
    };
  }

  render() {
    return (
      <Fragment>
        <div className="container">
          <div className="row">
            <div className="column">
              <table className="table">
                <thead>
                  <tr>
                    <th>id</th>
                    <th>product_name</th>
                    <th>product_category</th>
                    <th>unit_price</th>
                  </tr>
                </thead>
                <tbody>
                  {this.state.tabledata.map((item) => (
                    <tr key={item.id}>
                      <td>{item.product_name}</td>
                      <td>{item.product_category}</td>
                      <td>{item.unit_price}</td>
                      <td>{item.unit_price}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default Table;
