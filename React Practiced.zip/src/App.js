import React, { Fragment } from "react";
import ReactDOM from "react-dom";
import Ajio from "./Ajio";
import Greetingcard from "./Greetingcard";
import Greetingmsg2 from "./Greetingmsg2";
import ProductItem from "./ProductItem";
import styles from "./styles.css";
import Table from "./Table";
import Task from "./Task";
import Task1 from "./Task1";
import Wishcard from "./Wishcard";
import Books from "./ExBooks/Books.js";
let App = () => {
  return (
    <Fragment>
      <nav className="nav">
        <a href="/">Books List</a>
      </nav>
      <Wishcard />
      <Greetingcard />
      <Greetingmsg2 />
      <ProductItem />
      <Table />
      <Ajio />

      <Task1 />
    </Fragment>
  );
};

export default App;
