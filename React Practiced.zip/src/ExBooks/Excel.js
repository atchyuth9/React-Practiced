import axios from "axios";
const Book_Api_Url = "http://localhost:8088/api/excel/books";
class Excel {
  getBooks() {
    axios.get(Book_Api_Url);
  }
}
export default new Excel();
