import React, { Fragment } from "react";
import axios from "axios";
class Task extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      users: null,
      errorMessage: null
    };
  }
  componentDidMount() {
    axios
      .get("http://localhost:8088/api/excel/books")
      .then((responce) => {
        this.setState({
          users: responce.data
        });
      })
      .catch(() => {
        this.setState({
          errorMessage: err
        });
      });
  }

  render() {
    return (
      <Fragment>
        <div className="container">
          <div className="row">
            <div className="col">
              <h2>user info</h2>
              <p>user info</p>
            </div>
          </div>
          <div className="row">
            <div className="col">
              <table className="table">
                <thead>
                  <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>UserName</th>
                    <th>Email</th>
                    <th>Address</th>
                  </tr>
                </thead>
                <tbody>
                  {this.state.users ? (
                    <Fragment>
                      {this.state.users.map((user) => {
                        return (
                          <tr>
                            <td>{user.id}</td>
                            <td>{user.name}</td>
                            <td>{user.username}</td>
                            <td>{user.email}</td>
                            <td>{user.address.city}</td>
                          </tr>
                        );
                      })}
                    </Fragment>
                  ) : null}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default Task;
